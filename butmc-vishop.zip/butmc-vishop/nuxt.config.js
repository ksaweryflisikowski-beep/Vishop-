module.exports = {
  /*
  ** Headers of the page
  */
  publicRuntimeConfig: {
    shop_id: 31798, // id sklepu na vishop
    headline: "Doładuj swój portfel i graj bez ograniczeń", // duży napis na stronie głównej
    description: "Sklep serwera BUTMC.PL. Wybierz tryb, wpisz nick i gotowe. Zakupy realizują się automatycznie zaraz po płatności.", // opis serwera
    first_color: "#f27a0c",  // pierwszy kolor (pomarańcz)
    second_color: "#ffb347",  // drugi kolor (jasny pomarańcz)
    address: "butmc.pl",  // adres serwera
    brand: { before: "BUT", accent: "MC", after: ".PL" }, // nazwa w nagłówku, accent jest w kolorze
    discord: "", // link do zaproszenia na Discorda, np. "https://discord.gg/twojzaproszenie"
    facebook: "" // opcjonalnie link do Facebooka
  },
  head: {
    title: 'BUTMC.PL - sklep serwera Minecraft',  // tytuł strony
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: 'Sklep serwera Minecraft BUTMC.PL. Wybierz tryb, wpisz nick i kup od razu.' }  // opis strony dla wyszukiwarek i discorda
    ],
    link: [
      { rel: 'icon', type: 'image/png', href: '/logo-sm.png' },
      { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Lexend:wght@600;800&display=swap'}
    ]
  },
  /*
  ** Poniższa konfiguracja jest dla bardziej zaawansowanych użytkowników, nie ma tam nic ciekawego
  */
  server: {
    host: '0.0.0.0'
  },
  css: [
    "~/node_modules/bootstrap/dist/css/bootstrap.min.css"
  ],
  plugins: [
      { src: "~/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js", mode: "client" },
      { src: "~/plugins/price.js"}
  ],
  modules: [
    "vue-toastification/nuxt"
  ],
  /*
  ** Customize the progress bar color
  */
  loading: { color: '#3B8070' },
  /*
  ** Build configuration
  */
  build: {
    /*
    ** Run ESLint on save
    */
    extend (config, { isDev, isClient }) {
      if (isDev && isClient) {
        config.module.rules.push({
          enforce: 'pre',
          test: /\.(js|vue)$/,
          loader: 'eslint-loader',
          exclude: /(node_modules)/
        })
      }
    }
  }
}

