<template>
  <div class="container home">
    <section class="hero" aria-labelledby="hero-title">
      <canvas ref="bg" class="hero-bg" aria-hidden="true"></canvas>
      <div class="hero-text">
        <h1 id="hero-title">{{$config.headline || $store.state.shop.name}}</h1>
        <p>{{$config.description}}</p>
        <div class="cta">
          <button type="button" class="btn-dark" @click="copy()">Skopiuj IP serwera</button>
          <a v-if="$config.discord" class="btn-light custom-btn" :href="$config.discord" target="_blank" rel="noopener">Dołącz na Discorda</a>
          <a v-else class="btn-light custom-btn" href="#servers">Sklep</a>
        </div>
      </div>
      <div class="hero-art"><img src="/logo.png" :alt="'Logo ' + $store.state.shop.name" width="694" height="720"></div>
    </section>

    <div class="shop" id="servers">
      <section class="card-x">
        <h2>Tryby serwera</h2>
        <p class="sub">Wybierz tryb serwera, aby przejść do sklepu.</p>
        <div class="servers">
          <div v-for="server in $store.state.servers" :key="server.id" class="bg-second p-4 server">
            <img v-if="server.image" :src="server.image" alt="Zdjęcie trybu" width="250" height="250">
            <span class="server-name">{{server.name}}</span>
            <nuxt-link :to="'/server/' + server.id" class="custom-btn gradient-button w-100 mt-auto">Wybierz</nuxt-link>
          </div>
        </div>
      </section>

      <aside class="side">
        <div v-if="$config.discord" class="discord">
          <small>WIDZIAŁEŚ NASZEGO DISCORDA?</small>
          <h3>Na nim dowiesz się wszystkich potrzebnych informacji!</h3>
          <a class="custom-btn" :href="$config.discord" target="_blank" rel="noopener">Dołącz już teraz</a>
        </div>
        <div class="card-x">
          <div class="status">
            <i class="led" :class="{ off: !$store.state.status.online }"></i>
            <div>
              <b>{{ $store.state.status.online ? 'Serwer online' : 'Serwer offline' }}</b>
              <span>{{$config.address}} · graczy: {{$store.state.status.players}}</span>
            </div>
          </div>
          <div class="ip"><span>{{$config.address}}</span><button type="button" @click="copy()">Kopiuj</button></div>
        </div>
      </aside>
    </div>

    <section v-if="$store.state.shop.richest_player && richestPlayer && richestPlayer.player" class="card-x podium">
      <h2>Najbogatszy gracz</h2>
      <p class="sub">Gracz, który wydał w sklepie najwięcej.</p>
      <div class="slot">
        <div class="crown" aria-hidden="true">♛</div>
        <img :src="`https://minotar.net/avatar/` + richestPlayer.player + `/92`" :alt="richestPlayer.player" width="92" height="92">
        <span class="nick">{{richestPlayer.player}}</span>
        <span class="sum">{{richestPlayer.spend}} zł</span>
        <div class="step">1</div>
      </div>
    </section>

    <section class="voucher" aria-labelledby="v-title">
      <div>
        <small>NASZ KOD</small>
        <h3 id="v-title">Posiadasz voucher?</h3>
        <p>Wpisz kod i odbierz swoje środki w kilka sekund.</p>
      </div>
      <nuxt-link to="/voucher" class="custom-btn btn-dark">Zrealizuj voucher</nuxt-link>
    </section>
  </div>
</template>

<script>
export default {
  data () {
    return { richestPlayer: null }
  },
  async mounted () {
    this.paint()
    window.addEventListener('resize', this.onResize)
    if (this.$store.state.shop.richest_player) {
      await fetch(`https://dev123.vishop.pl/panel/shops/${this.$config.shop_id}/richest_player/`)
        .then((response) => response.json())
        .then((data) => { this.richestPlayer = data })
        .catch((err) => console.error(err))
    }
  },
  beforeDestroy () {
    window.removeEventListener('resize', this.onResize)
    clearTimeout(this.rt)
  },
  methods: {
    copy () {
      try {
        navigator.clipboard.writeText(this.$config.address)
        this.$toast.success('Skopiowano adres serwera')
      } catch (e) {
        this.$toast.info('IP serwera: ' + this.$config.address)
      }
    },
    onResize () {
      clearTimeout(this.rt)
      this.rt = setTimeout(this.paint, 150)
    },
    // blokowe tło w hero
    paint () {
      const c = this.$refs.bg
      if (!c) return
      const p = c.parentElement
      const r = window.devicePixelRatio || 1
      const w = p.clientWidth
      const h = p.clientHeight
      c.width = w * r
      c.height = h * r
      const g = c.getContext('2d')
      g.scale(r, r)
      const s = 44
      let seed = 7
      const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 }
      const cols = ['255,240,200', '255,200,110', '255,150,40', '190,80,5', '120,45,0']
      for (let y = 0; y < h; y += s) {
        for (let x = 0; x < w; x += s) {
          const k = Math.floor(rnd() * cols.length)
          const a = 0.10 + rnd() * 0.28
          g.fillStyle = 'rgba(' + cols[k] + ',' + a + ')'
          g.fillRect(x, y, s, s)
        }
      }
    }
  }
}
</script>

<style scoped>
.home { display: flex; flex-direction: column; gap: 20px; padding-bottom: 20px; }
.hero {
  position: relative;
  overflow: hidden;
  border-radius: 28px;
  background: linear-gradient(135deg, #ffc25e 0%, #f7931e 55%, #e8670a 100%);
  display: grid;
  grid-template-columns: 1.1fr .9fr;
  align-items: center;
  gap: 8px;
  padding: clamp(24px, 5vw, 56px);
  min-height: 340px;
  isolation: isolate;
}
.hero-bg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  filter: blur(1.5px);
  opacity: .7;
}
.hero h1 { color: #1b140c; font-size: clamp(30px, 5.2vw, 56px); line-height: 1.04; }
.hero p { margin: 14px 0 0; max-width: 46ch; color: #3a230c; font-weight: 500; }
.cta { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 22px; }
.btn-dark { background: #1b140c; color: #fff; }
.btn-light { background: #fff; color: #2b2bd6; }
.btn-dark:hover, .btn-light:hover { transform: translateY(-2px); }
.btn-dark:hover { color: #fff; }
.btn-light:hover { color: #2b2bd6; }
.hero-art { display: grid; place-items: center; }
.hero-art img {
  width: min(100%, 360px);
  height: auto;
  filter: drop-shadow(0 18px 24px rgba(60, 25, 0, .35));
  animation: float 5s ease-in-out infinite;
}
@keyframes float { 50% { transform: translateY(-10px) rotate(-1.5deg); } }
@media (max-width: 820px) {
  .hero { grid-template-columns: 1fr; }
  .hero-art img { width: min(70%, 280px); }
}

.shop { display: grid; grid-template-columns: minmax(0, 1.25fr) minmax(0, .75fr); gap: 20px; align-items: start; }
@media (max-width: 900px) { .shop { grid-template-columns: 1fr; } }
.card-x {
  background: var(--surface);
  border: 2px solid var(--line);
  border-radius: 26px;
  padding: clamp(18px, 3vw, 30px);
  box-shadow: var(--shadow);
}
.card-x h2 { font-size: clamp(24px, 3.4vw, 32px); }
.sub { margin: 4px 0 0; color: var(--muted); }
.servers { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-top: 22px; }
.server { display: flex; flex-direction: column; align-items: center; gap: 8px; }
.server img { max-width: 100%; height: auto; }
.server-name { font-family: var(--font-display); font-weight: 800; font-size: 20px; text-align: center; }
.side { display: flex; flex-direction: column; gap: 20px; }
.discord {
  position: relative;
  overflow: hidden;
  border-radius: 26px;
  background: linear-gradient(135deg, #7b86ff, #5865f2);
  color: #fff;
  padding: 26px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.discord small { font-weight: 700; letter-spacing: .08em; font-size: 11px; opacity: .85; }
.discord h3 { font-size: 22px; line-height: 1.15; }
.discord .custom-btn { background: #fff; color: #4650d6; align-self: flex-start; }
.discord::after {
  content: "";
  position: absolute;
  right: -30px;
  bottom: -30px;
  width: 140px;
  height: 140px;
  border-radius: 30px;
  background: rgba(255, 255, 255, .14);
  transform: rotate(18deg);
}
.status { display: flex; align-items: center; gap: 12px; }
.led {
  flex: none;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--ok);
  box-shadow: 0 0 0 5px color-mix(in srgb, var(--ok) 25%, transparent);
}
.led.off { background: var(--bad); box-shadow: 0 0 0 5px color-mix(in srgb, var(--bad) 25%, transparent); }
.status b { font-family: var(--font-display); font-size: 18px; }
.status span { color: var(--muted); font-size: 13px; display: block; }
.ip {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-top: 14px;
  background: var(--field);
  border: 2px dashed var(--line);
  border-radius: 14px;
  padding: 10px 12px 10px 16px;
  font-family: var(--font-display);
  font-weight: 600;
}
.ip button { background: var(--first-color); color: var(--on-accent); border-radius: 10px; padding: 8px 14px; font-size: 14px; }

.podium .slot { display: flex; flex-direction: column; align-items: center; max-width: 220px; margin: 26px auto 0; }
.crown { height: 26px; color: var(--second-color); font-size: 22px; line-height: 26px; }
.slot img { image-rendering: pixelated; border-radius: 8px; }
.nick { font-weight: 700; font-size: 14px; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 6px; }
.sum { color: var(--muted); font-size: 13px; font-variant-numeric: tabular-nums; }
.step {
  width: 100%;
  height: 120px;
  margin-top: 10px;
  border-radius: 14px 14px 0 0;
  display: grid;
  place-items: center;
  font-family: var(--font-display);
  font-weight: 800;
  font-size: 28px;
  color: var(--on-accent);
  background: linear-gradient(var(--second-color), var(--first-color));
}

.voucher {
  border-radius: 26px;
  background: linear-gradient(120deg, #ffd166, #ffb347);
  color: #1b140c;
  padding: clamp(20px, 3vw, 32px);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  flex-wrap: wrap;
}
.voucher small { font-weight: 700; letter-spacing: .08em; font-size: 11px; opacity: .7; }
.voucher h3 { font-size: clamp(22px, 3vw, 28px); }
.voucher p { margin: 4px 0 0; opacity: .8; }
.voucher .btn-dark:hover { color: #fff; }
</style>
