<template>
  <div :style="cssVars" class="app">
    <component :is="`style`">{{$store.state.shop.style}}</component>
    <Navbar/>
    <nuxt/>
    <Footer/>
  </div>
</template>

<script>
import Navbar from '~/components/Navbar.vue'
import Footer from '~/components/Footer.vue'

export default {
  components: {
    Navbar, Footer
  },
  computed: {
    cssVars() {
      return {
        '--first-color': this.$config.first_color,
        '--second-color': this.$config.second_color
      }
    }
  }
}
</script>

<style>
:root {
  --bg: #fffaf3; --surface: #ffffff; --ink: #1b140c; --muted: #7a6c5c; --line: #f3e1c8;
  --field: #fff6e8; --on-accent: #1b140c; --discord: #5865f2; --ok: #1f9d55; --bad: #d6342c;
  --shadow: 0 10px 30px -12px rgba(120, 60, 0, .28);
  --font-display: "Lexend", "Arial Black", system-ui, sans-serif;
  --font-body: "Inter", system-ui, -apple-system, "Segoe UI", sans-serif;
  color-scheme: light;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #120e0a; --surface: #1c1610; --ink: #fbf1e4; --muted: #a89885; --line: #3a2c1d;
    --field: #251b12; --shadow: 0 10px 30px -12px rgba(0, 0, 0, .7);
    color-scheme: dark;
  }
}

html, body {
  font-family: var(--font-body);
  font-size: 15px;
  line-height: 1.5;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
  background: var(--bg);
  color: var(--ink);
}
*, *:before, *:after {
  box-sizing: border-box;
  margin: 0;
}
h1, h2, h3 {
  font-family: var(--font-display);
  letter-spacing: -.02em;
  font-weight: 800;
}
h1 { font-size: clamp(28px, 4.6vw, 44px); }
a { color: var(--first-color); }
a:hover { color: inherit; }
:focus-visible { outline: 3px solid var(--first-color); outline-offset: 2px; border-radius: 8px; }

.container {
  max-width: 1120px !important;
  width: 100%;
  padding-left: 16px;
  padding-right: 16px;
}

/* przyciski */
button, .custom-btn {
  color: var(--on-accent);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 13px 20px;
  text-align: center;
  border: none;
  border-radius: 14px;
  font-family: inherit;
  font-size: 15px;
  font-weight: 700;
  transition: transform .15s, filter .15s, background .15s;
  text-decoration: none;
}
.gradient-button, .gradient-button:hover {
  background: linear-gradient(135deg, var(--second-color) 0%, var(--first-color) 100%);
  color: var(--on-accent);
}
.gradient-button:hover:not(:disabled) {
  transform: translateY(-2px);
  filter: brightness(1.05);
  cursor: pointer;
}
.card-btn { position: absolute; bottom: -22px; }

/* karty */
.bg-second {
  background: var(--surface) !important;
  border: 2px solid var(--line);
  border-radius: 26px;
  box-shadow: var(--shadow);
}

/* pola */
.input-txt {
  width: 100%;
  min-width: 0;
  border: 2px solid var(--line);
  border-radius: 14px;
  padding: 13px 14px;
  background: var(--field);
  color: var(--ink);
  font: inherit;
  outline: none;
  transition: border-color .15s, box-shadow .15s;
}
.input-txt::placeholder { color: var(--muted); opacity: .7; }
.input-txt:focus {
  border-color: var(--first-color);
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--first-color) 22%, transparent);
}
input:disabled { opacity: 0.5; }

@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
</style>
