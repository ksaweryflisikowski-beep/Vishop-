<template>
  <header class="top container">
    <nuxt-link to="/" class="brand">
      <img src="/logo-sm.png" alt="" width="48" height="48">
      <span v-if="$config.brand">{{$config.brand.before}}<b>{{$config.brand.accent}}</b>{{$config.brand.after}}</span>
      <span v-else>{{$store.state.shop.name}}</span>
    </nuxt-link>

    <div class="online" :title="status.online ? 'Serwer online' : 'Serwer offline'">
      <i class="led" :class="{ off: !status.online }"></i>{{status.players}}
    </div>

    <button class="burger" type="button" aria-label="Włącz nawigację" :aria-expanded="String(open)" @click="open = !open">
      <span></span><span></span><span></span>
    </button>

    <nav class="nav" :class="{ open: open }" aria-label="Menu">
      <nuxt-link to="/" class="nav-link" v-if="$store.state.shop.home_link">Strona główna</nuxt-link>
      <template v-for="navElement in $store.state.shop.navigation">
        <nuxt-link :key="navElement.id" :to="'/subpage/'+navElement.subpage" class="nav-link" v-if="navElement.subpage">{{navElement.name}}</nuxt-link>
        <a :key="navElement.id" :href="navElement.url" class="nav-link" v-else>{{navElement.name}}</a>
      </template>
      <nuxt-link to="/voucher" class="nav-link">Voucher</nuxt-link>
      <a v-if="$config.discord" :href="$config.discord" target="_blank" rel="noopener" class="nav-link pill">Discord</a>
    </nav>
  </header>
</template>

<script>
export default {
  name: "Navbar",
  data () {
    return { open: false }
  },
  computed: {
    status () {
      return this.$store.state.status
    }
  },
  watch: {
    '$route' () {
      this.open = false
    }
  },
  created () {
    if (process.client) {
      this.$store.dispatch('loadStatus')
    }
  }
}
</script>

<style scoped>
.top {
  display: flex;
  align-items: center;
  gap: 14px;
  padding-top: 16px;
  padding-bottom: 16px;
  position: relative;
}
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  text-decoration: none;
  color: var(--ink);
  font-family: var(--font-display);
  font-weight: 800;
  font-size: 20px;
}
.brand:hover { color: var(--ink); }
.brand img { width: 48px; height: 48px; object-fit: contain; }
.brand b { color: var(--first-color); }
.online {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14px;
  background: var(--field);
  border: 2px solid var(--line);
  border-radius: 999px;
  padding: 4px 12px;
}
.led {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--ok);
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--ok) 25%, transparent);
}
.led.off {
  background: var(--bad);
  box-shadow: 0 0 0 4px color-mix(in srgb, var(--bad) 25%, transparent);
}
.nav {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 6px;
}
.nav-link {
  text-decoration: none;
  font-weight: 600;
  font-size: 14px;
  padding: 8px 12px;
  border-radius: 999px;
  color: var(--muted);
  white-space: nowrap;
}
.nav-link:hover, .nav-link.nuxt-link-exact-active { background: var(--field); color: var(--ink); }
.nav-link.pill, .nav-link.pill:hover { background: var(--discord); color: #fff; }
.burger {
  display: none;
  margin-left: auto;
  flex-direction: column;
  gap: 5px;
  padding: 12px;
  background: var(--field);
  border: 2px solid var(--line);
}
.burger span {
  display: block;
  width: 20px;
  height: 2px;
  background: var(--ink);
  border-radius: 2px;
}
@media (max-width: 760px) {
  .burger { display: flex; }
  .nav {
    display: none;
    position: absolute;
    top: 100%;
    left: 16px;
    right: 16px;
    z-index: 20;
    flex-direction: column;
    align-items: stretch;
    background: var(--surface);
    border: 2px solid var(--line);
    border-radius: 20px;
    padding: 10px;
    box-shadow: var(--shadow);
  }
  .nav.open { display: flex; }
  .nav-link { text-align: center; padding: 12px; }
}
</style>
