# butmc-vishop

Szablon VIshop.pl dla BUTMC.PL (Nuxt 2, ta sama struktura i ten sam sposób działania co `vbasic`).

Ustawienia (ID sklepu, kolory, adres serwera, link do Discorda, nazwa w nagłówku) są na górze pliku
`nuxt.config.js` w `publicRuntimeConfig`. ID sklepu: 31798.

``` bash
npm install
npm run dev      # podgląd lokalny na http://localhost:3000
npm run build && npm start
```

Licencja VIshop: stopka (`components/Footer.vue`) zawiera wymagany akapit o VIshop.pl. Nie usuwaj go ani nie zmieniaj jego treści.
